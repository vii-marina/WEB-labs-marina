let currentYear, currentMonth;
let selectedDate;

document.addEventListener('DOMContentLoaded', function () {

  function updateDateTime() {
    const now = new Date();
    const formattedDateTime = now.toLocaleString();
    document.getElementById('datetime').textContent = formattedDateTime;
  }

  function renderCalendar(year = currentYear, month = currentMonth) {
    const now = new Date();
    const today = now.getDate();
    const calendarContainer = document.getElementById('calendar');
    calendarContainer.innerHTML = ''; // Очищуємо календар

    const monthNames = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    document.getElementById('month-year').textContent = `${monthNames[month]} ${year}`;

    const firstDayOfMonth = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const isCurrentMonth = year === now.getFullYear() && month === now.getMonth();

    const calendarGrid = document.createElement('div');
    calendarGrid.classList.add('calendar-grid');

    // Завантажуємо важливі дати з localStorage
    const importantDates = JSON.parse(localStorage.getItem('importantDates') || '{}');
    const monthKey = `${year}-${month}`;

    // Додаємо пусті комірки перед першим днем
    for (let i = 0; i < firstDayOfMonth; i++) {
      const emptyCell = document.createElement('span');
      emptyCell.classList.add('calendar-cell', 'empty-cell');
      calendarGrid.appendChild(emptyCell);
    }

    // Додаємо дні місяця
    for (let day = 1; day <= daysInMonth; day++) {
      const dayCell = document.createElement('span');
      dayCell.classList.add('calendar-cell');
      dayCell.textContent = day;

      // Виділяємо сьогоднішню дату
      if (isCurrentMonth && day === today) {
        dayCell.classList.add('today');
      }

      // Стилізація важливих дат
      if (importantDates[monthKey] && importantDates[monthKey][day]) {
        dayCell.classList.add(importantDates[monthKey][day]);
      }

      // Подвійний клік для вибору важливої дати
      dayCell.addEventListener('dblclick', () => {
        selectedDate = { day, monthKey, dayCell };
        openModal();
      });

      calendarGrid.appendChild(dayCell);
    }

    calendarContainer.appendChild(calendarGrid);
  }

  function openModal() {
    document.getElementById('date-modal').style.display = 'block';
  }

  function closeModal() {
    document.getElementById('date-modal').style.display = 'none';
  }

  // Зберегти обрану подію
  document.getElementById('save-date').addEventListener('click', () => {
    const eventType = document.getElementById('event-type').value;
    if (eventType) {
      const importantDates = JSON.parse(localStorage.getItem('importantDates') || '{}');
      if (!importantDates[selectedDate.monthKey]) {
        importantDates[selectedDate.monthKey] = {};
      }
      importantDates[selectedDate.monthKey][selectedDate.day] = eventType;
      localStorage.setItem('importantDates', JSON.stringify(importantDates));
      selectedDate.dayCell.className = 'calendar-cell ' + eventType; // Оновлюємо клас для стилізації
    }
    closeModal();
  });

  // Видалити обрану подію
  document.getElementById('delete-date').addEventListener('click', () => {
    const importantDates = JSON.parse(localStorage.getItem('importantDates') || '{}');
    if (importantDates[selectedDate.monthKey] && importantDates[selectedDate.monthKey][selectedDate.day]) {
      delete importantDates[selectedDate.monthKey][selectedDate.day];
      localStorage.setItem('importantDates', JSON.stringify(importantDates));
      selectedDate.dayCell.className = 'calendar-cell'; // Очищуємо стилі
    }
    closeModal();
  });

  // Закрити модальне вікно при кліку на "x"
  document.querySelector('.close').addEventListener('click', closeModal);

  // Закрити модальне вікно при кліку поза ним
  window.addEventListener('click', function (event) {
    if (event.target == document.getElementById('date-modal')) {
      closeModal();
    }
  });

  // Події для кнопок переключення місяців
  document.getElementById('prev-month').addEventListener('click', () => {
    currentMonth -= 1;
    if (currentMonth < 0) {
      currentMonth = 11;
      currentYear -= 1;
    }
    renderCalendar(currentYear, currentMonth);
  });

  document.getElementById('next-month').addEventListener('click', () => {
    currentMonth += 1;
    if (currentMonth > 11) {
      currentMonth = 0;
      currentYear += 1;
    }
    renderCalendar(currentYear, currentMonth);
  });

  // Початкове завантаження
  const now = new Date();
  currentYear = now.getFullYear();
  currentMonth = now.getMonth();
  updateDateTime();
  renderCalendar();

  // Оновлення часу кожну секунду
  setInterval(updateDateTime, 1000);
});
